"""Unit tests for neuro_dot.Temporal_Transforms on small synthetic signals."""
import numpy as np
import pytest

import neuro_dot as ndot

FS = 10.0  # Hz
T = np.arange(0, 200, 1 / FS)  # 200 s -> 2000 samples


def _band_power(x, f, fs=FS):
    """Amplitude of the sinusoid at frequency f in each row of x."""
    n = x.shape[-1]
    spec = np.abs(np.fft.rfft(x, axis=-1)) * 2 / n
    freqs = np.fft.rfftfreq(n, 1 / fs)
    return spec[..., np.argmin(np.abs(freqs - f))]


# --- logmean -----------------------------------------------------------------

def test_logmean_docstring_example():
    data = np.array([[1, 10, 100], [np.e, 10 * np.e, 100 * np.e]], dtype=float)
    out, phi0 = ndot.logmean(data)
    expected = np.array([[3.6109, 1.3083, -0.9943]] * 2)
    np.testing.assert_allclose(out, expected, atol=1e-4)
    np.testing.assert_allclose(phi0, data.mean(axis=1))


def test_logmean_constant_rows_are_zero():
    out, _ = ndot.logmean(np.full((4, 50), 7.0))
    np.testing.assert_allclose(out, 0.0, atol=1e-12)


# --- detrend_tts ---------------------------------------------------------------

def test_detrend_removes_linear_trend_and_mean():
    sig = np.sin(2 * np.pi * 0.5 * T)
    data = np.vstack([sig + 3 * T + 10, sig - 0.2 * T])
    out = ndot.detrend_tts(data)
    assert out.shape == data.shape
    np.testing.assert_allclose(out.mean(axis=1), 0, atol=1e-10)
    for row in out:
        slope = np.polyfit(T, row, 1)[0]
        assert abs(slope) < 1e-6


# --- highpass / lowpass ------------------------------------------------------

def _two_tone(n_rows=3):
    slow = np.sin(2 * np.pi * 0.01 * T)  # 0.01 Hz
    fast = np.sin(2 * np.pi * 1.0 * T)  # 1 Hz
    return np.tile(slow + fast, (n_rows, 1))


def test_highpass_keeps_fast_removes_slow():
    data = _two_tone()
    out = ndot.highpass(data, 0.1, FS)
    assert out.shape == data.shape
    assert np.all(np.isfinite(out))
    assert np.all(_band_power(out, 1.0) > 0.9)
    assert np.all(_band_power(out, 0.01) < 0.05)
    np.testing.assert_allclose(out.mean(axis=1), 0, atol=1e-10)


def test_lowpass_keeps_slow_removes_fast():
    slow = np.sin(2 * np.pi * 0.05 * T)
    fast = np.sin(2 * np.pi * 2.0 * T)
    data = np.tile(slow + fast, (3, 1))
    out = ndot.lowpass(data, 0.5, FS)
    assert out.shape == data.shape
    assert np.all(np.isfinite(out))
    assert np.all(_band_power(out, 0.05) > 0.8)
    assert np.all(_band_power(out, 2.0) < 0.01)


@pytest.mark.xfail(
    reason="With DoPad=0, Npad is 0 and data_out[:, 0:-0] returns an empty array",
    strict=True,
)
def test_highpass_without_padding():
    data = _two_tone()
    out = ndot.highpass(data, 0.1, FS, params={"DoPad": 0})
    # Npad = 0 makes the trailing slice data_out[:, 0:-0] empty.
    assert out.shape == data.shape


# --- fft_tts -----------------------------------------------------------------

def test_fft_tts_peak_at_signal_frequency():
    f0 = 1.5
    data = np.tile(np.sin(2 * np.pi * f0 * T), (2, 1))
    ftdomain, ftmag, ftpower, _ = ndot.fft_tts(data, FS)
    assert ftdomain[0] == 0
    assert ftdomain[-1] == pytest.approx(FS / 2)
    assert ftmag.shape == (2, ftdomain.size)
    np.testing.assert_allclose(ftdomain[np.argmax(ftmag, axis=1)], f0, atol=0.01)
    np.testing.assert_allclose(ftpower, ftmag ** 2)


@pytest.mark.xfail(
    reason="nextpow2 uses '^' (bitwise XOR) instead of '**' and never "
    "terminates for N > 3",
    run=False,
    strict=True,
)
def test_nextpow2():
    assert ndot.nextpow2(5) == 8
    assert ndot.nextpow2(1000) == 1024


# --- resample_tts ------------------------------------------------------------

def test_resample_tts_halves_rate_and_keeps_trend():
    data = np.vstack([np.linspace(0, 10, T.size), np.linspace(5, -5, T.size)])
    info = {
        "system": {"framerate": FS},
        "paradigm": {"synchpts": np.array([1, 100, 1000])},
    }
    out, info_out = ndot.resample_tts(data, info, omega_resample=5, framerate=FS)
    assert info_out["system"]["framerate"] == 5
    assert out.shape == (2, T.size // 2)
    # The function is designed to preserve linear components exactly.
    np.testing.assert_allclose(out[:, 0], data[:, 0], atol=1e-8)
    np.testing.assert_allclose(out[:, -1], data[:, -1], atol=0.05)
    np.testing.assert_array_equal(info_out["paradigm"]["synchpts"], [1, 50, 500])
    np.testing.assert_array_equal(info_out["paradigm"]["init_synchpts"], [1, 100, 1000])
    # Input info must not be mutated.
    assert info["system"]["framerate"] == FS


# --- gethem / regcorr --------------------------------------------------------

def _pairs_info(n_per_wl=4):
    wl = np.repeat([1, 2], n_per_wl)
    r2d = np.tile([5, 12, 13, 30], 2)[: 2 * n_per_wl]
    return {"pairs": {"WL": wl, "r2d": r2d}}


def test_gethem_averages_shallow_measurements_per_wavelength(rng):
    info = _pairs_info()
    nm = info["pairs"]["WL"].size
    data = rng.standard_normal((nm, 100))
    info["MEAS"] = {"GI": np.ones(nm, dtype=bool)}
    hem = ndot.gethem(data, info)  # default r2d window [10, 16]
    assert hem.shape == (2, 100)
    np.testing.assert_allclose(hem[0], data[[1, 2]].mean(axis=0))
    np.testing.assert_allclose(hem[1], data[[5, 6]].mean(axis=0))


@pytest.mark.xfail(
    reason="gethem raises KeyError when info has no 'MEAS' key (the 'MEAS' and "
    "'GI' checks are evaluated together), and uses np.bool8, which NumPy 2 removed",
    strict=True,
)
def test_gethem_without_good_measurement_mask(rng):
    """When info has no MEAS.GI, every measurement should count as good."""
    info = _pairs_info()
    data = rng.standard_normal((info["pairs"]["WL"].size, 50))
    hem = ndot.gethem(data, info)
    np.testing.assert_allclose(hem[0], data[[1, 2]].mean(axis=0))


def test_regcorr_removes_regressor(rng):
    info = _pairs_info()
    nm, nt = info["pairs"]["WL"].size, 200
    noise = rng.standard_normal((2, nt))
    data = np.vstack([np.outer(np.arange(1, 5), noise[0]), np.outer(np.arange(1, 5), noise[1])])
    out, R = ndot.regcorr(data, info, noise)
    assert out.shape == (nm, nt)
    assert R.shape == (nm, 1)
    np.testing.assert_allclose(out, 0, atol=1e-10)
    np.testing.assert_allclose(np.abs(R), 1, atol=1e-10)
