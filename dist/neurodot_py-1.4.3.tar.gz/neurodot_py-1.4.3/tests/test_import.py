"""The package and every submodule must import cleanly."""
import importlib

import pytest

SUBMODULES = [
    "Analysis",
    "DynamicFilter",
    "File_IO",
    "Light_Modeling",
    "Matlab_Equivalent_Functions",
    "Reconstruction",
    "Spatial_Transforms",
    "Temporal_Transforms",
    "Visualizations",
]


def test_package_imports():
    import neuro_dot  # noqa: F401


@pytest.mark.parametrize("name", SUBMODULES)
def test_submodule_imports(name):
    importlib.import_module(f"neuro_dot.{name}")
