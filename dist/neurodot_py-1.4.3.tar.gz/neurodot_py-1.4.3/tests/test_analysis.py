"""Unit tests for neuro_dot.Analysis helpers."""
import numpy as np
import pytest

import neuro_dot as ndot


def test_fisher_r2z_matches_arctanh_and_is_finite():
    r = np.array([-1.0, -0.5, 0.0, 0.5, 1.0])
    z = ndot.fisher_r2z(r)
    assert np.all(np.isfinite(z))
    np.testing.assert_allclose(z[1:4], np.arctanh(r[1:4]))
    assert z[0] < -8 and z[-1] > 8


def test_normcND_gives_unit_columns(rng):
    x = rng.standard_normal((30, 5))
    np.testing.assert_allclose(np.linalg.norm(ndot.normcND(x), axis=0), 1.0)


def test_normrND_on_row_vector(rng):
    x = rng.standard_normal((1, 30))
    np.testing.assert_allclose(np.linalg.norm(ndot.normrND(x)), 1.0)


def test_normalize_rows_handles_zero_rows(rng):
    x = np.vstack([rng.standard_normal(10), np.zeros(10)])
    out = ndot.normalize_rows(x)
    assert np.linalg.norm(out[0]) == pytest.approx(1.0)
    np.testing.assert_array_equal(out[1], 0)


def test_rms_py():
    x = np.array([[3.0, 0.0], [4.0, 0.0]])
    np.testing.assert_allclose(ndot.rms_py(x), [np.sqrt(12.5), 0.0])


def test_calc_gvtd_constant_signal_is_zero():
    gvtd = ndot.CalcGVTD(np.ones((5, 40)))
    assert gvtd.shape == (40,)
    np.testing.assert_allclose(gvtd, 0)


def test_calc_gvtd_detects_step():
    data = np.zeros((4, 20))
    data[:, 10:] = 2.0
    gvtd = ndot.CalcGVTD(data)
    assert np.argmax(gvtd) == 10
    assert gvtd[10] == pytest.approx(2.0)


def _blocks(noise=0.0, seed=0):
    dt = 10
    template = np.sin(np.linspace(0, np.pi, dt))
    pulses = [0, 20, 40, 60]
    data = np.random.default_rng(seed).standard_normal((2, 80)) * noise
    for p in pulses:
        data[:, p : p + dt] += template
    return data, pulses, dt, template


def test_block_average_recovers_repeated_response():
    data, pulses, dt, template = _blocks(noise=1e-3)
    ba, bstd, bt, blocks = ndot.BlockAverage(data, list(pulses), dt)
    assert ba.shape == bstd.shape == bt.shape == (2, dt)
    assert blocks.shape == (2, dt, len(pulses))
    np.testing.assert_allclose(ba, np.tile(template - template.mean(), (2, 1)), atol=5e-3)
    assert np.all(bstd < 5e-3)


@pytest.mark.xfail(
    reason="BlockAverage adds 1 to every entry of the caller's pulse list/array in "
    "place, so calling it twice with the same pulses shifts the blocks",
    strict=True,
)
def test_block_average_does_not_modify_pulse_argument():
    data, pulses, dt, _ = _blocks(noise=1e-3)
    pulse = list(pulses)
    ndot.BlockAverage(data, pulse, dt)
    assert pulse == pulses


@pytest.mark.xfail(
    reason="BT_out[np.argwhere(np.isinf(BT_out))] = 0 indexes rows with (row, col) "
    "pairs, so any zero-std sample raises IndexError or zeroes the wrong rows",
    strict=True,
)
def test_block_average_zero_variance_gives_zero_t():
    data, pulses, dt, _ = _blocks(noise=0.0)
    _, _, bt, _ = ndot.BlockAverage(data, list(pulses), dt)
    assert np.all(np.isfinite(bt))
