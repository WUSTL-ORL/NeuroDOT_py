"""End-to-end smoke test of the preprocessing chain on bundled sample data.

Checks that the steps run together on real data and produce finite output of
the right shape. It does not check numerical values against MATLAB.
"""
import numpy as np
import pytest

import neuro_dot as ndot


@pytest.fixture(scope="module")
def sample(sample_mat_path):
    d = ndot.loadmat(str(sample_mat_path))
    return d["data"], d["info"]


def test_sample_data_structure(sample):
    data, info = sample
    nm, nt = data.shape
    assert nm == info["pairs"]["WL"].size
    assert nt > 100
    assert info["system"]["framerate"] > 0


@pytest.mark.slow
def test_preprocessing_chain(sample):
    data, info = sample
    fr = info["system"]["framerate"]
    data = data[:200]  # subset of measurements keeps CI fast

    lml, _ = ndot.logmean(data)
    assert np.all(np.isfinite(lml))

    dt = ndot.detrend_tts(lml)
    hp = ndot.highpass(dt, 0.02, fr)
    lp = ndot.lowpass(hp, 1.0, fr)
    assert lp.shape == data.shape
    assert np.all(np.isfinite(lp))

    rs, info_rs = ndot.resample_tts(lp, info, omega_resample=1, framerate=fr)
    assert info_rs["system"]["framerate"] == 1
    expected_nt = data.shape[1] / fr
    assert abs(rs.shape[1] - expected_nt) <= 2
    assert np.all(np.isfinite(rs))
