"""Unit tests for neuro_dot.Spatial_Transforms."""
import numpy as np
import pytest

import neuro_dot as ndot


@pytest.mark.parametrize("axis", ["x", "y", "z"])
@pytest.mark.parametrize("theta", [0.0, np.pi / 6, np.pi / 2, -1.0])
def test_rotation_matrix_is_proper_rotation(axis, theta):
    rot = ndot.rotation_matrix(axis, theta)
    assert rot.shape == (3, 3)
    np.testing.assert_allclose(rot @ rot.T, np.eye(3), atol=1e-12)
    assert np.linalg.det(rot) == pytest.approx(1.0)
    # The rotation axis itself is left unchanged.
    e = np.eye(3)["xyz".index(axis)]
    np.testing.assert_allclose(rot @ e, e, atol=1e-12)


def test_rotation_matrix_z_quarter_turn():
    rot = ndot.rotation_matrix("z", np.pi / 2)
    np.testing.assert_allclose(rot @ [1, 0, 0], [0, 1, 0], atol=1e-12)


def test_rotate_cap_zero_rotation_is_identity(rng):
    tpos = rng.standard_normal((20, 3)) * 50
    np.testing.assert_allclose(ndot.rotate_cap(tpos, [0, 0, 0]), tpos, atol=1e-10)


def test_rotate_cap_preserves_geometry(rng):
    tpos = rng.standard_normal((20, 3)) * 50
    out = ndot.rotate_cap(tpos, [10, -25, 40])
    assert out.shape == tpos.shape
    np.testing.assert_allclose(out.mean(axis=0), tpos.mean(axis=0), atol=1e-10)

    def pdist(p):
        return np.linalg.norm(p[:, None] - p[None], axis=-1)

    np.testing.assert_allclose(pdist(out), pdist(tpos), atol=1e-9)


def test_good_vox2vol_places_voxels_in_fortran_order():
    dim = {"nVx": 2, "nVy": 3, "nVz": 2, "Good_Vox": np.array([1, 5, 12])}
    img = np.array([[1.0, 10.0], [2.0, 20.0], [3.0, 30.0]])  # 3 voxels x 2 time
    vol = ndot.GoodVox2vol(img, dim)
    assert vol.shape == (2, 3, 2, 2)
    flat = vol.reshape(-1, 2, order="F")
    np.testing.assert_array_equal(flat[[0, 4, 11]], img)
    assert np.count_nonzero(vol) == img.size


def test_good_vox2vol_accepts_row_vector():
    dim = {"nVx": 2, "nVy": 2, "nVz": 1, "Good_Vox": np.array([1, 2, 3, 4])}
    vol = ndot.GoodVox2vol(np.array([[1.0, 2.0, 3.0, 4.0]]), dim)
    assert vol.shape == (2, 2, 1, 1)
